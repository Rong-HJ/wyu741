package 作业一;

public class Vehicle {
    private int speed;
    private int size;

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    //加速方法
    public void speedUp(){
        System.out.println("加速" );
    }

    //减速
    public void speedDown(){
        System.out.println("减速");
    }

    public String toString(Vehicle v){
        String str = "车的速度是：" + v.getSpeed() + " " + "车的体积是:" + v.getSize() ;
        return str;
    }
}
