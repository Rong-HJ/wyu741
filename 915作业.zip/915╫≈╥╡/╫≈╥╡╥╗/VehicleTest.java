package 作业一;

public class VehicleTest {
    public static void main(String[] args) {
        Vehicle car = new Vehicle();
        //给属性赋值并输出
        car.setSpeed(40);
        car.setSize(3) ;

        String str = car.toString(car) ;
        System.out.println(str);

        //调用加速和减速方法
        car.speedDown() ;
        car.speedUp();
    }
}
