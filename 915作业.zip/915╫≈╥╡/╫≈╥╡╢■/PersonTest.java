package 作业二;

public class PersonTest {
    public static void main(String[] args) {
        Person male1 = new Person();
        Person male2 = new Person("阿信" , 18,"男");
        Person female = new Person("Alin" , 19);

    }

}
