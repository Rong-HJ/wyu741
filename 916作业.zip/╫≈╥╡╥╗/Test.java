package 作业一;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test {
    public static void main(String[] args) {

        String times = "2020-01-11";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();

        try {
            //转换的返回值是对象
            date = sdf.parse(times);
            System.out.println(date);
           //转换的返回值是字符串
            System.out.println(sdf.format(date));

            Emp emp = new Emp(25,"男",5000,sdf.parse(times));
            System.out.println(emp.toString());

        } catch (ParseException e) {
            e.printStackTrace();
        }



    }
}
